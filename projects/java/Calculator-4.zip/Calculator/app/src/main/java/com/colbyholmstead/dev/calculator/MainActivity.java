package com.colbyholmstead.dev.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.widget.Toolbar;

import java.util.Arrays;

import static java.lang.Double.doubleToLongBits;
import static java.lang.Double.parseDouble;
import static java.lang.Integer.parseInt;

public class MainActivity extends AppCompatActivity {


  Button calculateButton;
  Button decimalButton;
  EditText editRunningResult;
  EditText editResult;
  String displayResult = "";
  String pendingOp = "";
  String currentOp = "";
  //    String newNumberString = "";
  Double currentResult = null;
  Double newNumberDouble = 0.0;
  boolean hasDecimal = false;
  String[] currentNumber = {};
  String[] history = {};


  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);


    editResult = findViewById(R.id.editResult);
    calculateButton = findViewById(R.id.calculateButton);
    editRunningResult = findViewById(R.id.editRunningResult);
    decimalButton = findViewById(R.id.decimalButton);
    Intent intent = getIntent();
    displayResult = intent.getStringExtra("result");
    if(displayResult != null){
      currentResult = parseDouble(displayResult);
    }
    editResult.setText(displayResult);
    
//    Toolbar toolbar = findViewById(R.id.toolbar);
//    toolbar.setTitle("Calculator");
//    setSupportActionBar( toolbar );

  }

@Override
public boolean onCreateOptionsMenu(Menu menu){
  MenuInflater inflater = getMenuInflater();
  inflater.inflate( R.menu.menu, menu );
    return true;
}

  @Override
  public boolean onOptionsItemSelected(MenuItem item){
// I think this is where you run the start activity
    switch(item.getItemId()){
      case R.id.menuCalculator:

        return true;
      case R.id.menuConversion:
        if(currentResult == null){
          currentResult = 0.0;
          Intent conversionIntent = new Intent(this, Conversions.class);
          conversionIntent.putExtra("editResult", currentResult.toString());
          startActivity(conversionIntent);
        }else {
          Intent conversionIntent = new Intent(this, Conversions.class);
          conversionIntent.putExtra("editResult", currentResult.toString());
          startActivity(conversionIntent);
        }
        return true;
      case R.id.menuHistory:
        Intent historyIntent = new Intent(this, history.class);
        startActivity(historyIntent);
        return true;
      case R.id.menuAbout:
        Intent aboutIntent = new Intent(this, about.class);
        startActivity(aboutIntent);
        return true;
      default:
        return  super.onOptionsItemSelected(item);
    }


  }

  public void numberButtonOnClick(View v) {
    String buttonString = ((Button) v).getText().toString();
    if (buttonString.equals(".")) {
      if (!hasDecimal) {
        currentNumber = addToArray(currentNumber, buttonString);
        if (isInteger(buttonString) || history.length > 0) {
          editRunningResult.setText(findRunningTotalString(buttonString));
        }
        hasDecimal = true;
      }
    } else {
      currentNumber = addToArray(currentNumber, buttonString);
      if (isInteger(buttonString) || history.length > 0) {
        editRunningResult.setText(findRunningTotalString(buttonString));
      }
    }
//    editResult.setText(buildString(currentNumber));
// todo make this a loop that goes through history and builds the problem from scratch in calculate.
//
//    if (isInteger(buttonString)) {
//      if (buttonString.contains(".")) {
//        if (!buildString(currentNumber).contains(".")) {
//          currentNumber = add(currentNumber, buttonString);
//          decimalButton.setEnabled(false);
////                    Log.i("TEST", "You found me");
//        }
//      } else {
//        currentNumber = add(currentNumber, buttonString);
//      }
//    } else if (buttonString.contains("Back")) {
//      currentNumber = back(currentNumber);
//      if (!buildString(currentNumber).contains(".")) {
//        decimalButton.setEnabled(true);
//      }
//      // possibly calc here on back
//    } else {
//      newNumberDouble = parseDouble(buildString(currentNumber));
//      if (currentResult == null) {
//        currentResult = newNumberDouble;
//      } else {
//        if (pendingOp != null) {
//          Log.i("OPER", "You the " + pendingOp);
//          currentResult = calculate(pendingOp, currentResult, newNumberDouble);
//          pendingOp = buttonString;
//          Log.i("OPER", "You pressed the " + pendingOp);
//        } else {
//          pendingOp = buttonString;
//
//
//        }
//
//
//      }
//
//
//    }
//    editResult.setText(String.valueOf(currentResult));
//         end todo
    // for history view along bottom edit text only
//        if (isInteger(buttonString) || history.length > 0) {
//            editRunningResult.setText(findRunningTotalString(buttonString));
//        }
  }

  public void conversionsButtonOnClick(View v) {
    if(currentResult == null){
      currentResult = 0.0;
      Intent conversionIntent = new Intent(this, Conversions.class);
      conversionIntent.putExtra("editResult", currentResult.toString());
      startActivity(conversionIntent);
    }else {
      Intent conversionIntent = new Intent(this, Conversions.class);
      conversionIntent.putExtra("editResult", currentResult.toString());
      startActivity(conversionIntent);
    }
  }

  public void operationButtonOnClick(View v) {
    String buttonString = ((Button) v).getText().toString();
    if (buttonString.equals("RANDOM")) {
//      Log.i("FOUND", "FOUND ME");
      editResult.setText(String.valueOf(Math.random()));
    } else if (buttonString.equals("π")) {
      editResult.setText(String.valueOf(3.14159265358));
    } else {
      hasDecimal = false;
      // build new number nd wipe out the spot for the last one.
      try {
        //  Block of code to try
        Log.i("EXT", "TRY ME");
        newNumberDouble = parseDouble(buildString(currentNumber));
//    Log.i("CALCU", newNumberDouble + " is in the result");
        // todo add current number to history
        if (currentResult == null) {
          currentResult = newNumberDouble;
          editResult.setText(String.valueOf(currentResult));
        }
        if (!pendingOp.equals("")) {
          currentResult = calculate(currentResult, newNumberDouble);
        }
      } catch (Exception e) {
        Log.i("EXT", "CATCH ME");
        //  Block of code to handle errors
      }
      editRunningResult.setText(findRunningTotalString(buttonString));
      pendingOp = buttonString;
      editResult.setText(String.valueOf(currentResult));

    }
    currentNumber = new String[0];
  }


  public void backButtonOnClick(View v) {
    String currentString = (editResult).getText().toString();
    Log.i("CALCR", currentString);
    editResult.setText(currentString.substring(0, currentString.length() - 1));
  }


  public void clearButtonOnClick(View v) {
    decimalButton.setEnabled(true);
    currentResult = null;
    history = new String[0];
    displayResult = "";
    hasDecimal = false;
    editRunningResult.setText(displayResult);
    editResult.setText(displayResult);
    currentNumber = new String[0];
    pendingOp = "";

  }


  public void calculateButtonOnClick(View v) {
    if (buildString(currentNumber).equals("")) {
      Log.i("CALCR", "You pressed the " + pendingOp + " button");
      currentResult = calculate(currentResult);
      Log.i("CALCU", currentResult + " is in the result");
      editResult.setText(String.valueOf(currentResult));
      pendingOp = "";

    } else {
      newNumberDouble = parseDouble(buildString(currentNumber));
      Log.i("CALCR", "You pressed the " + pendingOp + " button");
      currentResult = calculate(currentResult, newNumberDouble);
      Log.i("CALCU", currentResult + " is in the result");
      editResult.setText(String.valueOf(currentResult));
      pendingOp = "";
    }

  }


  // Copies the result to the clipboard
  public void resultOnClick(View v) {
    String resultString = ((EditText) v).getText().toString();
    Log.i("COPY", resultString + " is in the result");
    ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
    ClipData clip = ClipData.newPlainText(resultString, resultString);
    clipboard.setPrimaryClip(clip);
    Toast.makeText(getApplicationContext(), "Copied To Clipboard", Toast.LENGTH_LONG).show();
    Log.i("CLIPBOARD", clipboard.getText().toString());
  }
  //todo responsible for all
//    private Double calculate() {
//
////     currentResult, newNumberDouble are the two things needed
//
//
//        return
//    }
//


  private Double calculate(Double currentResult, Double newNumberDouble) {
    double answer = 0.0;
    if (!pendingOp.equals("")) {
      switch (pendingOp) {
        case "+":
          // addition
          Log.i("CALC", "You pressed the " + pendingOp + " button");
          answer = currentResult + newNumberDouble;
          break;
        case "-":
          // subtraction
          Log.i("CALC", "You pressed the " + pendingOp + " button");
          answer = currentResult - newNumberDouble;
          break;
        case "x":
          // multiply
          Log.i("CALC", "You pressed the " + pendingOp + " button");
          answer = currentResult * newNumberDouble;
          break;
        case "÷":
          // divide
          Log.i("CALC", "You pressed the " + pendingOp + " button");
          answer = currentResult / newNumberDouble;
          break;
        case "%":
          // divide
          Log.i("CALC", "You pressed the " + pendingOp + " button");
          answer = (currentResult / newNumberDouble) * 100;
          break;
        default:
          System.out.println("Error");
          answer = 344.04;
          break;
      }
    }
    return answer;
  }


  private Double calculate(Double currentResult) {
    double answer = 0.0;
    if (!pendingOp.equals("")) {
      switch (pendingOp) {
        case "√":
          // divide
          Log.i("CALC", "You pressed the " + pendingOp + " button");
          answer = Math.sqrt(currentResult);
          break;
        case "COS":
          // divide
          Log.i("CALC", "You pressed the " + pendingOp + " button");
          answer = Math.cos(currentResult);
          break;
        case "RANDOM":
          // divide
          Log.i("CALC", "You pressed the " + pendingOp + " button");
          answer = Math.random();
          break;
        case "π":
          // divide
          Log.i("CALC", "You pressed the " + pendingOp + " button");
          answer = 3.14159265358;
          break;
        case "SIN":
          // divide
          Log.i("CALC", "You pressed the " + pendingOp + " button");
          answer = Math.sin(currentResult);
          break;
        case "TAN":
          // divide
          Log.i("CALC", "You pressed the " + pendingOp + " button");
          answer = Math.tan(currentResult);
          break;
        case "x2":
          // divide
          Log.i("CALC", "You pressed the " + pendingOp + " button");
          answer = currentResult * currentResult;
          break;
        case "±":
          // divide
          Log.i("CALC", "You pressed the " + pendingOp + " button");
          if (currentResult < 0) {
            answer = +currentResult;
          } else {
            answer = -currentResult;
          }
          break;
        default:
          System.out.println("Error");
          answer = 344.04;
          break;

      }

    }
    return answer;


  }


  private Double calculate() {
    double answer = 0.0;
    if (!pendingOp.equals("")) {
      switch (pendingOp) {
        case "RANDOM":
          // divide
          Log.i("CALC", "You pressed the " + pendingOp + " button");
          answer = Math.random();
          break;
        case "π":
          // divide
          Log.i("CALC", "You pressed the " + pendingOp + " button");
          answer = 3.14159265358;
          break;
        default:
          System.out.println("Error");
          answer = 344.04;
          break;

      }

    }
    return answer;


  }


  private Double calculate(String buttonString, Double currentResult, Double newNumberDouble) {
    double answer = 0.0;
    if (!pendingOp.equals("")) {
      switch (pendingOp) {
        case "+":
          // addition
          Log.i("CALC", "You pressed the " + pendingOp + " button");
          answer = currentResult + newNumberDouble;
          break;
        case "-":
          // subtraction
          Log.i("CALC", "You pressed the " + pendingOp + " button");
          answer = currentResult - newNumberDouble;
          break;
        case "x":
          // multiply
          Log.i("CALC", "You pressed the " + pendingOp + " button");
          answer = currentResult * newNumberDouble;
          break;
        case "÷":
          // divide
          Log.i("CALC", "You pressed the " + pendingOp + " button");
          answer = currentResult / newNumberDouble;
          break;
        default:
          System.out.println("Error");
          answer = 344.04;
          break;
      }


    }
    pendingOp = buttonString;
    return answer;
  }


  private String buildString(String[] array) {
    StringBuilder string = new StringBuilder();
    for (int i = 0; i < array.length; i++) {
      string.append(array[i]);
    }
    return string.toString();
  }

  // gets the string for the history along the bottom editText
  private String findRunningTotalString(String buttonString) {
//        Log.i("CALC", "You pressed the " + buttonString + " button");
    if (buttonString.contains("Back")) {
      history = back(history);
      return buildString(history);
    } else {
      history = addToArray(history, buttonString);
//            history = add(history, buttonString);
      return buildString(history);
    }
  }

  private String[] addToArray(String[] array, String string) {
    array = Arrays.copyOf(array, array.length + 1);
    array[array.length - 1] = string;
    return array;
  }


  private String[] back(String[] history) {
    if (history.length > 0) {
      history = Arrays.copyOf(history, history.length - 1);
    }
    return history;
  }

  // todo possably need to fix this.
  public boolean isInteger(String string) {
    if (string.equals(".")) {
      return true;
    }
    try {
      Integer.valueOf(string);
      return true;
    } catch (NumberFormatException e) {
      return false;
    }

  }


}
