package com.colbyholmstead.dev.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Array;

public class Conversions extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

  EditText result;
  EditText resultTo;
  Double fromDouble;
  Double toDouble;
  String resultString = "";
  String conversionResult = "";
  ListView listview;
TextView fromTag;
  TextView toTag;

  String[] items = {
      "Millimeters to Inches",
      "Centimeters to Inches",
      "Meters to Inches",
      "Kilometers to Inches",
      "Feet to Inches",
      "Yards to Inches",
      "Miles to Inches",
      "Inches to Millimeters",
      "Inches to Centimeters",
      "Inches to Meters",
      "Inches to Kilometers",
      "Inches to Feet",
      "Inches to Yards",
      "Inches to Miles",
      "Feet to Millimeters",
      "Feet to Centimeters",
      "Feet to Meters",
      "Feet to Kilometers",
      "Feet to Yards",
      "Feet to Miles",
      "Millimeters to Feet",
      "Centimeters to Feet",
      "Meters to Feet",
      "Kilometers to Feet",
      "Yards to Feet",
      "Miles to Feet",
      "Yards to Millimeters",
      "Yards to Centimeters",
      "Yards to Meters",
      "Yards to Kilometers",
      "Yards to Miles",
      "Millimeters to Yards",
      "Centimeters to Yards",
      "Meters to Yards",
      "Kilometers to Yards",
      "Miles to Yards",
      "Millimeters to Miles",
      "Centimeters to Miles",
      "Meters to Miles",
      "Kilometers to Miles",
      "Miles to Millimeters",
      "Miles to Centimeters",
      "Miles to Meters",
      "Miles to Kilometers"
  };
  Double[] conversionRates = {
      0.0393701,
      0.393701,
      39.3701,
      39370.1,
      12.0,
      36.0,
      63360.0,
      25.4,
      2.54,
      0.0254,
      2.54e-5,
      0.0833333,
      0.0277778,
      1.5783e-5,
      304.8,
      30.48,
      0.3048,
      0.0003048,
      0.333333,
      0.000189394,
      0.00328084,
      0.0328084,
      3.28084,
      3280.84,
      3.0,
      5280.0,
      914.4,
      91.44,
      0.9144,
      0.0009144,
      0.000568182,
      0.00109361,
      0.0109361,
      1.09361,
      1093.61,
      1760.0,
      6.2137e-7,
      6.2137e-6,
      0.000621371,
      0.621371,
      1.609e+6,
      160899.999998412,
      1609.34,
      1.60934
  };
  String[] from = {
      "Millimeters",
      "Centimeters",
      "Meters",
      "Kilometers",
      "Feet",
      "Yards",
      "Miles",
      "Inches",
      "Inches",
      "Inches",
      "Inches",
      "Inches",
      "Inches",
      "Inches",
      "Feet",
      "Feet",
      "Feet",
      "Feet",
      "Feet",
      "Feet",
      "Millimeters",
      "Centimeters",
      "Meters",
      "Kilometers",
      "Yards",
      "Miles",
      "Yards",
      "Yards",
      "Yards",
      "Yards",
      "Yards",
      "Millimeters",
      "Centimeters",
      "Meters",
      "Kilometers",
      "Miles",
      "Millimeters",
      "Centimeters",
      "Meters",
      "Kilometers",
      "Miles",
      "Miles",
      "Miles",
      "Miles"
  };
  String[] to = {
      "Inches",
      "Inches",
      "Inches",
      "Inches",
      "Inches",
      "Inches",
      "Inches",
      "Millimeters",
      "Centimeters",
      "Meters",
      "Kilometers",
      "Feet",
      "Yards",
      "Miles",
      "Millimeters",
      "Centimeters",
      "Meters",
      "Kilometers",
      "Yards",
      "Miles",
      "Feet",
      "Feet",
      "Feet",
      "Feet",
      "Feet",
      "Feet",
      "Millimeters",
      "Centimeters",
      "Meters",
      "Kilometers",
      "Miles",
      "Yards",
      "Yards",
      "Yards",
      "Yards",
      "Yards",
      "Miles",
      "Miles",
      "Miles",
      "Miles",
      "Millimeters",
      "Centimeters",
      "Meters",
      "Kilometers"
  };



  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_conversions);
    result = findViewById(R.id.result);
    resultTo = findViewById(R.id.resultTo);
    Intent intent = getIntent();
    resultString = intent.getStringExtra("editResult");
    Log.i("EXT", "CATCH ME" + resultString);
    result.setText(resultString);
    toTag = findViewById(R.id.toTag);
    fromTag = findViewById(R.id.fromTag);
    toTag.setText(to[0]);
    fromTag.setText(to[0]);
    listview = findViewById(R.id.listViewConversion);
    ArrayAdapter adapter = new ArrayAdapter<String>(this, R.layout.conversion_item, items);
    listview.setAdapter(adapter);
    listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
      @Override
      public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        // from the position I should be able to grab the string
        performConversion(position);
      }
    });
  }

  public void performConversion(int position) {
    fromDouble = Double.parseDouble(result.getText().toString());
    toDouble = fromDouble * conversionRates[position];
    resultTo.setText(Double.toString(toDouble));
    toTag.setText(to[position]);
    fromTag.setText(from[position]);

  }
//  public void calculationButtonOnClick(View v) {
//
////Intent calculationIntent = new Intent(this, MainActivity.class);
////calculationIntent.putExtra("result", result.getText().toString());
////startActivity(calculationIntent);
//  }

  @Override
  public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
    // do stuff here
    String text = parent.getItemAtPosition(position).toString();
    Toast.makeText(parent.getContext(), text, Toast.LENGTH_SHORT).show();

  }

  @Override
  public void onNothingSelected(AdapterView<?> parent) {
  }


  @Override
  public boolean onCreateOptionsMenu(Menu menu) {
    MenuInflater inflater = getMenuInflater();
    inflater.inflate(R.menu.menu, menu);
    return true;
  }

  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
// I think this is where you run the start activity
    switch (item.getItemId()) {
      case R.id.menuCalculator:
        Intent calculationIntent = new Intent(this, MainActivity.class);
        calculationIntent.putExtra("result", Double.parseDouble(resultTo.getText().toString()));
        startActivity(calculationIntent);
        return true;
      case R.id.menuConversion:
//        if(currentResult == null){
//          currentResult = 0.0;
//          Intent conversionIntent = new Intent(this, Conversions.class);
//          conversionIntent.putExtra("editResult", currentResult.toString());
//          startActivity(conversionIntent);
//        }else {
//          Intent conversionIntent = new Intent(this, Conversions.class);
//          conversionIntent.putExtra("editResult", currentResult.toString());
//          startActivity(conversionIntent);
//        }
//        return true;
      case R.id.menuHistory:
        Intent historyIntent = new Intent(this, history.class);
        startActivity(historyIntent);
        return true;
      case R.id.menuAbout:
        Intent aboutIntent = new Intent(this, about.class);
        startActivity(aboutIntent);
        return true;
      default:
        return super.onOptionsItemSelected(item);
    }
  }


}
