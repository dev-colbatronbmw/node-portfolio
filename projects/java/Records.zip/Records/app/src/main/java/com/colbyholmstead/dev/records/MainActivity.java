package com.colbyholmstead.dev.records;


import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;
import androidx.room.Room;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
  private AppDatabase recordDatabase;
  //  public LiveData<Record> record;
  public ListView listView;
  public List<String> tempItems = new ArrayList<String>();
  public LiveData<List<String>> items;
  public LiveData<List<String>> itemsCheck;
  public ArrayAdapter<String> adapter;
  public int recordIDNumber;
  public List<String> allNames;
  public boolean seed;



  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);
    String[] names = getResources().getStringArray(R.array.Names);
    String[] descriptions = getResources().getStringArray(R.array.Descriptions);
    if (recordDatabase == null) {

        recordDatabase = Room.databaseBuilder(getApplicationContext(),
            AppDatabase.class,
            "records.db")
            .fallbackToDestructiveMigration()
            .build();



    }
    // seed the database
    itemsCheck = recordDatabase.recordDao().getAllNames();
    itemsCheck.observe(this, new Observer<List<String>>() {
      @Override
      public void onChanged(List<String> strings) {
        allNames = strings;
        if(allNames.size() < 1){

          Toast.makeText(MainActivity.this, "seeded again" , Toast.LENGTH_SHORT).show();
          for (int i = 0; i < names.length; i++) {
            String seedName = names[i];
            String seedDesc = descriptions[i];
            new Thread(new Runnable() {
              @Override
              public void run() {
                Double seedPrice =    roundDouble( Math.random() * 10000 + 700, 2) ;
                int seedRating = (int) (Math.random() * 5 + 1);
                Record seed = new Record();
                seed.setName(seedName);
                seed.setDescription(seedDesc);
                seed.setPrice(seedPrice);
                seed.setRating(seedRating);
                seed.setDateCreated(new Date());
                recordDatabase.recordDao().addRecord(seed);
              }
            }
            ).start();
          }

        }
      }
    });


    items = recordDatabase.recordDao().getAllNames();
    items.observe(this, new Observer<List<String>>() {
      @Override
      public void onChanged(List<String> strings) {
        listView = findViewById(R.id.listViewRecords);
        adapter = new ArrayAdapter<String>(getApplicationContext(), R.layout.activity_listview, strings);
        allNames = strings;


        if(allNames.size() < 1){


        }



        listView.setAdapter(adapter);
        adapter.notifyDataSetChanged();
        listView.invalidateViews();
        listView.refreshDrawableState();
      }
    });
    listView = findViewById(R.id.listViewRecords);
    listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
      @Override
      public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        // todo find the id number of the position selected
        // find the name of the selected row then search the database for that name to get the id
//        Log.d("POSITION", "id of row selected " + id + "position " + position);
        String name = allNames.get(position);
        new Thread(new Runnable() {
          @Override
          public void run() {
            Record selectedRecord = recordDatabase.recordDao().findRecordByName(name);
            recordIDNumber = (int) selectedRecord.getRecordId();
//        Log.d("POSITION", "name " + name + "record id " + recordIDNumber);
            Intent showIntent = new Intent(getApplicationContext(), ShowActivity.class);
            showIntent.putExtra("RecordIDNumber", recordIDNumber);
            startActivity(showIntent);

          }
        }
        ).start();
//        Log.d("POSITION", "record " + recordIDNumber);
      }
    });

  }

  public void newRecordOnClick(View V) throws ParseException {
    Intent newIntent = new Intent(this, AddActivity.class);
    startActivity(newIntent);


  }

  public static double roundDouble(double value, int places) {
    double scale = Math.pow(10, places);
    return Math.round(value * scale) / scale;
  }
}
