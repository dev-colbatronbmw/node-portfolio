package com.colbyholmstead.dev.records;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;
import androidx.room.Room;

import android.content.Intent;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import static java.lang.Double.parseDouble;

public class AddActivity extends AppCompatActivity {
  public String recordName;
  public double recordPrice;
  public int recordRating;
  public String recordDescription;
  public LiveData<List<String>> items;
  public ArrayAdapter<String> adapter;
  public List<String> outStrings;
  public EditText edtRecordName;
  public EditText edtRecordDescription;
  public EditText edtRecordPrice;
  public Boolean matchName = false;
  // todo this is where you stopped you idiot


  private AppDatabase recordDatabase;

  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_add);

    edtRecordName = findViewById(R.id.edtName);
    edtRecordDescription = findViewById(R.id.edtDescription);
    edtRecordPrice = findViewById(R.id.edtPrice);


    if( recordDatabase == null) {
      recordDatabase = Room.databaseBuilder(getApplicationContext(),
          AppDatabase.class,
          "records.db")
          .fallbackToDestructiveMigration()
          .build();
    }


    items = recordDatabase.recordDao().getAllNames();
    items.observe(this, new Observer<List<String>>() {
      @Override
      public void onChanged(List<String> strings) {
        outStrings = strings;



      }
    });
  }


  public void onRadioButtonClicked(View view) {
    // Is the button now checked?
    boolean checked = ((RadioButton) view).isChecked();
    // Check which radio button was clicked
    switch (view.getId()) {
      case R.id.radio_one:
        if (checked)
          recordRating = 1;
        break;
      case R.id.radio_two:
        if (checked)
          recordRating = 2;
        break;
      case R.id.radio_three:
        if (checked)
          recordRating = 3;
        break;
      case R.id.radio_four:
        if (checked)
          recordRating = 4;
        break;
      case R.id.radio_five:
        if (checked)
          recordRating = 5;
        break;
    }
  }


  public void addRecordButtonClicked(View view) throws ParseException {
    recordName = edtRecordName.getText().toString();


    for (String string : outStrings){
      if (recordName.matches(string)) {
        Toast.makeText(AddActivity.this, "You did not enter a unique name", Toast.LENGTH_SHORT).show();
        matchName = true;
        return;
      }else{
        matchName = false;
      }
    }




    if (matchName) {
      Toast.makeText(this, "You did not enter a unique name", Toast.LENGTH_SHORT).show();
    } else if (recordName.matches(""  )){
      Toast.makeText(this, "You did not enter a valid name", Toast.LENGTH_SHORT).show();
    }else{
      recordDescription = edtRecordDescription.getText().toString();
      String priceString = edtRecordPrice.getText().toString();
      try {
        recordPrice = Double.parseDouble(priceString);
      } catch (NumberFormatException e) {
        // p did not contain a valid double
      }
      new Thread(new Runnable() {
        @Override
        public void run() {
          // if the name is not null and is not in the database proceed
          Record record = new Record();
          record.setName(recordName);
          record.setDescription(recordDescription);
          record.setRating(recordRating);
          record.setPrice(recordPrice);
          record.setDateCreated(new Date());
          Log.d("RECORD", "record " + recordName + " " + recordDescription + " " + recordPrice + " " + recordRating);
          recordDatabase.recordDao().addRecord(record);


        }
      }
      ).start();
      Intent mainIntent = new Intent(this, MainActivity.class);
      if (!matchName) {
        startActivity(mainIntent);
      }
    }
  }

}
