package com.colbyholmstead.dev.records;


import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;
import androidx.room.Room;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import java.util.Date;

public class EditActivity extends AppCompatActivity {
  private AppDatabase recordDatabase;
  public EditText edtName, edtDescription, edtPrice;
  public int recordRating;
  public Double recordPrice;
  public RadioButton rBtn1;
  public RadioButton rBtn2;
  public RadioButton rBtn3;
  public RadioButton rBtn4;
  public RadioButton rBtn5;
  public int recordId;
  public LiveData<Record> record;
public Record updatedRecord;
  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_edit);
    Intent intent = getIntent();
    recordId = intent.getIntExtra("editId", 1);
//    Log.d("POSITION", "record to edit " + recordId);
    rBtn1 = findViewById(R.id.radio_one);
    rBtn2 = findViewById(R.id.radio_two);
    rBtn3 = findViewById(R.id.radio_three);
    rBtn4 = findViewById(R.id.radio_four);
    rBtn5 = findViewById(R.id.radio_five);
    edtName = findViewById(R.id.edtEditName);
    edtDescription = findViewById(R.id.edtEditDesc);
    edtPrice = findViewById(R.id.edtEditPrice);
    if (recordDatabase == null) {
      recordDatabase = Room.databaseBuilder(getApplicationContext(),
          AppDatabase.class,
          "records.db")
          .fallbackToDestructiveMigration()
          .build();
    }
    record = recordDatabase.recordDao().findLiveRecordById(recordId);
    record.observe(this, new Observer<Record>() {
      @Override
      public void onChanged(Record record) {

        edtName.setText(record.getName());
        edtDescription.setText(record.getDescription().toString());
        edtPrice.setText(Double.toString(record.getPrice()));
        recordRating = record.getRating();

        switch (recordRating) {
          case 1:
            rBtn1.toggle();
            break;
          case 2:
            rBtn2.toggle();
            break;
          case 3:
            rBtn3.toggle();
            break;
          case 4:
            rBtn4.toggle();
            break;
          case 5:
            rBtn5.toggle();
            break;
        }


      }
    });

  }


  public void onRadioButtonClicked(View view) {
    // Is the button now checked?
    boolean checked = ((RadioButton) view).isChecked();
    // Check which radio button was clicked
    switch (view.getId()) {
      case R.id.radio_one:
        if (checked)
          recordRating = 1;
        break;
      case R.id.radio_two:
        if (checked)
          recordRating = 2;
        break;
      case R.id.radio_three:
        if (checked)
          recordRating = 3;
        break;
      case R.id.radio_four:
        if (checked)
          recordRating = 4;
        break;
      case R.id.radio_five:
        if (checked)
          recordRating = 5;
        break;
    }
  }

  public void editRecordButtonClicked(View view) {

    record.observe( this, new Observer<Record>() {
      @Override
      public void onChanged(Record record) {

        record.setDateModified(new Date());
        record.setName(edtName.getText().toString());
        record.setDescription(edtDescription.getText().toString());
        record.setRating(recordRating);

        String priceString = edtPrice.getText().toString();

        try{
          recordPrice = Double.parseDouble(priceString);
          record.setPrice(recordPrice);
        } catch (NumberFormatException e) {
          // p did not contain a valid double
        }

        new Thread(new Runnable() {
          @Override
          public void run() {

            recordDatabase.recordDao().updateRecord(record);

            Log.d("POSITION", "record updated " + record.getRecordId());
          }
        }
        ).start();

      }
    });




    Intent showIntent = new Intent(getApplicationContext(), ShowActivity.class);
    showIntent.putExtra("RecordIDNumber", recordId);
    startActivity(showIntent);


  }


}
