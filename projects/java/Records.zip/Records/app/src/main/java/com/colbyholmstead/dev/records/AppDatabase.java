package com.colbyholmstead.dev.records;

import androidx.room.Database;
import androidx.room.RoomDatabase;
//@Database(entities = {Event.class}, version = 4, exportSchema = false)
//public abstract class AppDatabase extends RoomDatabase {
//  public abstract EventDao eventDao();
//}
@Database(entities = {Record.class}, version = 7, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {
  public abstract RecordDao recordDao();
}