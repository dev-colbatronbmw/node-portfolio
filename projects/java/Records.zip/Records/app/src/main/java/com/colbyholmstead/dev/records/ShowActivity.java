package com.colbyholmstead.dev.records;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;
import androidx.room.Room;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;

import android.os.CountDownTimer;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Locale;

public class ShowActivity extends AppCompatActivity {
  private AppDatabase recordDatabase;
  public int recordRating;
  public LiveData<Record> record;
  public TextView txtName, txtDescription, txtPrice, txtRating, txtDateCreated, txtDateModified;
  public int recordId;
  public String recordName;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_show);
    Intent intent = getIntent();
    recordId = intent.getIntExtra("RecordIDNumber", 1);
//    Log.d("POSITION", "showing record " + recordId);
    txtName = findViewById(R.id.txtName);
    txtDescription = findViewById(R.id.txtDesc);
    txtPrice = findViewById(R.id.txtPrice);
    txtRating = findViewById(R.id.txtRating);
    txtDateCreated = findViewById(R.id.txtDateCreated);
    txtDateModified = findViewById(R.id.txtDateModified);
    if (recordDatabase == null) {
      recordDatabase = Room.databaseBuilder(getApplicationContext(),
          AppDatabase.class,
          "records.db")
          .fallbackToDestructiveMigration()
          .build();
    }
    record = recordDatabase.recordDao().findLiveRecordById(recordId);

      record.observe(this, new Observer<Record>() {
        @Override
        public void onChanged(Record record) {
          if (record == null) {
            Intent mainIntent = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(mainIntent);
          } else {
//            Log.d("POSITION", "record " + record.getName());
            txtName.setText(record.getName().toString());
            txtDescription.setText(record.getDescription().toString());
            txtPrice.setText(Double.toString(record.getPrice()));
            txtRating.setText(Integer.toString(record.getRating()));
            DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy", Locale.ENGLISH);
            String strCreatedDate = dateFormat.format(record.getDateCreated());
            txtDateCreated.setText(strCreatedDate);
            if (record.getDateModified() != null) {
              String strModifiedDate = dateFormat.format(record.getDateModified());
              txtDateModified.setText(strModifiedDate);
            } else {
              txtDateModified.setText(R.string.not_modified);
            }
          }
        }
      });


  }


  public void editButtonClicked(View view) {
    Intent editIntent = new Intent(getApplicationContext(), EditActivity.class);
    editIntent.putExtra("editId", recordId);
//    Log.d("POSITION", "sending to edit record " + recordId);
    startActivity(editIntent);
  }

  public void deleteRecordButtonClicked(View view) {





    DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
      @Override
      public void onClick(DialogInterface dialog, int which) {
        switch (which){
          case DialogInterface.BUTTON_POSITIVE:

    record.observe(ShowActivity.this, new Observer<Record>() {
      @Override
      public void onChanged(Record record) {
        new Thread(new Runnable() {
          @Override
          public void run() {



            if(record != null) {
              recordDatabase.recordDao().deleteRecord(record);
              Log.d("POSITION", "record " + record.getName());
             recordName = record.getName().toString();
            }
          }
        }
        ).start();


      }

    });
            finish();
            Intent mainIntent = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(mainIntent);

            Toast.makeText(ShowActivity.this, recordName + " Deleted" , Toast.LENGTH_SHORT).show();

            break;

          case DialogInterface.BUTTON_NEGATIVE:
            //No button clicked
            break;
        }
      }
    };

    AlertDialog.Builder builder = new AlertDialog.Builder(ShowActivity.this);
    builder.setMessage("Are you sure?").setPositiveButton("Yes", dialogClickListener)
        .setNegativeButton("No", dialogClickListener).show();




  }

}
