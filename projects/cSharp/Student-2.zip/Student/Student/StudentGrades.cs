﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using Student.Properties;

namespace Student
{
    public class StudentGrades
    {

        string _StudentFirstName;
        string _StudentLastName;
        string _StudentMiddleName;
        int _StudentID;
        string _Email;
        string _Address;
        int _Zip;
        bool _HonorRoll;
        DateTime _EnrolledDate;

        List<DateTime> CourseCompleted = new List<DateTime>();
        List<string> CourseQtrYr = new List<string>();
        List<double> CourseGrade = new List<double>();
        List<string> ClassList = new List<string>();



        // constructors


            public StudentGrades(string StudentFirstName,
        string StudentLastName,
        string StudentMiddleName,
        int StudentID,
        string Email,
        string Address,
        int Zip,
        //bool HonorRoll,
        DateTime EnrolledDate)
        {
            StudentFirstName = _StudentFirstName;
            StudentLastName = _StudentLastName;
            StudentMiddleName = _StudentMiddleName;
            StudentID = _StudentID;
            Email = _Email;
            Address = _Address;
            Zip = _Zip;
            //HonorRoll = _HonorRoll;
            EnrolledDate = _EnrolledDate;
        }
            public StudentGrades() { }


        public string StudentFirstName
        {
            get => _StudentFirstName;
            set
            {
                _StudentFirstName = value;
            }
        }

        public string StudentLastName
        {
            get => _StudentLastName;
            set
            {
                _StudentLastName = value;
            }
        }

        public string StudentMiddleName
        {
            get => _StudentMiddleName;
            set
            {
                _StudentMiddleName = value;
            }
        }

        public int StudentID
        {
            get => _StudentID;
            set
            {
                _StudentID = value;
            }
        }

        public string Email
        {
            get => _Email;
            set
            {
                _Email = value;
            }
        }

        public string Address
        {
            get => _Address;
            set
            {
                _Address = value;
            }
        }

        public int Zip
        {
            get => _Zip;
            set
            {
                _Zip = value;
            }
        }

        public DateTime EnrolledDate
        {
            get => _EnrolledDate;
            set
            {
                _EnrolledDate = value;
            }
        }

        //public bool HonorRoll
        //{
        //    get => _HonorRoll;
        //    set
        //    {
        //        _HonorRoll = value;
        //    }
        //}



       public string getName()
        {
            if(_StudentMiddleName.Length == 0 || _StudentMiddleName == null)
            {
              string fullName =  _StudentFirstName + " " + _StudentLastName;
                return fullName;
            }
            else
            {
                string fullName = _StudentFirstName + " " + _StudentMiddleName + " " + _StudentLastName;
                return fullName;
            }
        }


        public string getName(string FirstName, string LastName)
        {


            string fullName = FirstName + " " + LastName;
            return fullName;
        }
        public string getName(string FirstName, string MiddleName, string LastName)
        {
            string fullName = FirstName + " " + MiddleName + " " + LastName;
            return fullName;
        }


        



        public string getCityState(string Zip)
        {
            SqlConnection cn = new SqlConnection("Data Source=134.39.173.35;Initial Catalog=cholmstead_w19;User ID=cholmstead_w19;Password=Westindies1");




            cn.Open();




            SqlCommand cmd = new SqlCommand("select * from tblZipcodes " +
                  "where zip = " + Zip, cn);


            //  SqlParameter param = new SqlParameter();
            // param.ParameterName = "@zip";
            // param.Value = txtZip.Text;

            SqlDataReader rdrZip = cmd.ExecuteReader();
            rdrZip.Read();







            string city = rdrZip["city"].ToString().Trim();
            string state = rdrZip["State"].ToString().Trim();







            cn.Close();
            return city + ", " + state;

        }




        public string getAddress()
        {




             string getCityState()
            {
                SqlConnection cn = new SqlConnection("Data Source=134.39.173.35;Initial Catalog=cholmstead_w19;User ID=cholmstead_w19;Password=Westindies1");




                cn.Open();




                SqlCommand cmd = new SqlCommand("select * from tblZipcodes " +
                      "where zip = " + _Zip, cn);


            
                SqlDataReader rdrZip = cmd.ExecuteReader();
                rdrZip.Read();





                string city = rdrZip["city"].ToString().Trim();
                    string state = rdrZip["State"].ToString().Trim();

               





                cn.Close();
                return city + ", " + state;
            }





            return getName() + Environment.NewLine + _Address + Environment.NewLine + getCityState();
        }


        public string getAddress(string fullName, string Address, string Zip)
        {          
            


            return fullName + Environment.NewLine + Address + Environment.NewLine + getCityState(Zip);
        }




        
        public void AddClassProps(DateTime courseCompletedDate, string strCourseQtrYr, double dblCourseGrade)
        {

            CourseCompleted.Add(courseCompletedDate);

            Settings.Default["compltedDate"] = courseCompletedDate;
            Settings.Default.Save();
            CourseQtrYr.Add(strCourseQtrYr);

            Settings.Default["QtrYr"] = strCourseQtrYr;
            Settings.Default.Save();

            CourseGrade.Add(dblCourseGrade);

            Settings.Default["Grade"] = dblCourseGrade;

            Settings.Default.Save();

        }

        //public void AddCourseCompleted(DateTime courseCompletedDate )
        //{
        //    CourseCompleted.Add(courseCompletedDate);

        //    Settings.Default["compltedDate"] = courseCompletedDate;
        //    Settings.Default.Save();
        //}

        //public void AddCourseQtrYr(string strCourseQtrYr)
        //{
        //    CourseQtrYr.Add(strCourseQtrYr);

        //    Settings.Default["QtrYr"] = strCourseQtrYr;
        //    Settings.Default.Save();
        //}

        //public void AddCourseGrade(double dblCourseGrade)
        //{
        //    CourseGrade.Add(dblCourseGrade);

        //    Settings.Default["Grade"] = dblCourseGrade;

        //    Settings.Default.Save();

        //}

        public void getClassList(DateTime courseCompletedDate, string strCourseQtrYr, double dblCourseGrade)
        {



            string strAdd = courseCompletedDate.ToShortDateString() + strCourseQtrYr + dblCourseGrade.ToString();

            ClassList.Add(strAdd);
            

            Settings.Default["List"] = strAdd;


           
        }


      public double getGPA()
        {
            return CourseGrade.Average();
        }

      public bool isHonorRoll()
        {
            if (getGPA() > 3.5)
            {
                _HonorRoll = true;
            }
            else
            {
                _HonorRoll = false;
            }

            return _HonorRoll;
        }







    }
}
