﻿using System;

namespace MovieObj
{

 

    public class oMovieCalc
    {

        private double oBaseTicket;
        private int oTheatreType;
        private int oTicketNum;
        private bool oStuDiscount;

        public oMovieCalc(double BasicTicket, int Quantity, bool StudentDiscount, int Theatre)
        {
            oBaseTicket = BasicTicket;
            oTheatreType = Theatre;
            oTicketNum = Quantity;
            oStuDiscount = StudentDiscount;
        }


        public oMovieCalc() { }


        public double BaseTicket
        {
            get {

                return oBaseTicket;
            }
            set
            {

                oBaseTicket = value;

            }
        }

        public int TicketNum
        {
            get { return oTicketNum; }
            set
            {
                oTicketNum = value;
            }
        }

        public bool StuDiscount
        {
            get { return oStuDiscount; }
            set
            {
                oStuDiscount = value;
            }
        }

        public int TheatreType
        {
            get { return oTheatreType; }
            set
            {
                oTheatreType = value;
            }
        }

        public double GetCost()
        {

          

            if(oStuDiscount == true)
            {
                oBaseTicket = 8.00;
            }
            else
            {
                oBaseTicket = 10.00;
            }

            if(oTheatreType == 2)
            {
                oBaseTicket = oBaseTicket + 3.00;
            }
            else if (oTheatreType == 3)
            {
                oBaseTicket = oBaseTicket - 0.50;
            }
            
                if (oTicketNum == 1 || oTicketNum > 1)
                {
                    return oBaseTicket;
                }
                else 
                {
                    return oBaseTicket * oTicketNum;
                }

         
          


       
            
           
        }



        public double GetCost(double BasicTicket, int Quantity, bool StudentDiscount, int Theatre)
        {




            if (StudentDiscount == true)
            {
                BasicTicket = 8.00;
            }
            else
            {
                BasicTicket = 10.00;
            }

            if (Theatre == 2)
            {
                BasicTicket = BasicTicket + 3.00;
            }
            else if (Theatre == 3)
            {
                BasicTicket = BasicTicket - 0.50;
            }

            
                if (Quantity == 1 || Quantity > 1)
                {
                    return BasicTicket;
                }
                else
                {
                    return BasicTicket * Quantity;
                }
            





          
        }

    }
}
