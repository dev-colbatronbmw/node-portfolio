//
//  Game+CoreDataClass.swift
//  Game
//
//  Created by Colby Holmstead on 3/18/20.
//  Copyright © 2020 Colby Holmstead. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Game)
public class Game: NSManagedObject {

}
