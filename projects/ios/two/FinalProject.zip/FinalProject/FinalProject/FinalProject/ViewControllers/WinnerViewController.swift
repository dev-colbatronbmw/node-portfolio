//
//  WinnerViewController.swift
//  FinalProject
//
//  Created by Colby Holmstead on 11/30/19.
//  Copyright © 2019 Colby Holmstead. All rights reserved.
//

import UIKit




class WinnerViewController: UIViewController {
  
    
    @IBOutlet var money: [UIImageView]!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
}
