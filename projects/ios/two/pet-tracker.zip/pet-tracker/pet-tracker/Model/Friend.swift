//
//  Friend.swift
//  pet-tracker
//
//  Created by Colby Holmstead on 2/14/20.
//  Copyright © 2020 Colby Holmstead. All rights reserved.
//

import Foundation
import UIKit

//struct Friend{
//    var id: UUID
//    var firstName: String
//    var lastName: String
//    var email: String
//    var age: Int
//    var eyeColor: UIColor
//    var image: UIImage
//    
//    init(id: UUID, firstName: String, lastName: String, email: String, age: Int, eyeColor: UIColor, image: UIImage){
//        self.id = id
//        self.firstName = firstName
//        self.lastName = lastName
//        self.email = email
//        self.age = age
//        self.eyeColor = eyeColor
//        self.image = image
//    }
//    
//    
//}
