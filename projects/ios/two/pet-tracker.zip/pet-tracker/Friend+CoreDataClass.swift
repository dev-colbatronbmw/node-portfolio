//
//  Friend+CoreDataClass.swift
//  pet-tracker
//
//  Created by Colby Holmstead on 3/16/20.
//  Copyright © 2020 Colby Holmstead. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Friend)
public class Friend: NSManagedObject {

}
