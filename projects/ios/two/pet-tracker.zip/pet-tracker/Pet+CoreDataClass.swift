//
//  Pet+CoreDataClass.swift
//  pet-tracker
//
//  Created by Colby Holmstead on 3/16/20.
//  Copyright © 2020 Colby Holmstead. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Pet)
public class Pet: NSManagedObject {

}
