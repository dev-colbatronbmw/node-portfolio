//
//  ServerViewController.swift
//  FinalProject
//
//  Created by Colby Holmstead on 11/3/19.
//  Copyright © 2019 Colby Holmstead. All rights reserved.
//

import UIKit

class ServerViewController: UIViewController {

    @IBOutlet var errorLabel: UILabel!
    @IBOutlet var serverNumTextField: UITextField!
    @IBOutlet var serverOKButton: UIButton!
    @IBOutlet var serverCancelButton: UIBarButtonItem!
   
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    @IBAction func serverOkButtonTapped(_ sender: UIButton) {
          checkForNum()
    }
       func checkForNum(){
           guard let setNumberText = serverNumTextField.text, !setNumberText.isEmpty else {
               errorLabel.isHidden = false
               return
           }
           if let setNumber = Int(setNumberText){
               if setNumber < 1 || setNumber > 1000 {
                   errorLabel.isHidden = false
               } else {
                   performSegue(withIdentifier: "ServerToGuess", sender: nil)
               }
           }else{
               errorLabel.isHidden = false
           }
       }
}
