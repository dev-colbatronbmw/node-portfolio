const express = require("express");
const { check } = require("express-validator");

const reviewsController = require("../controllers/reviewsController");

const reviewsRouter = express.Router();

function router() {
  const { getReviews, getTestimonials } = reviewsController();

  reviewsRouter.route("/").get(getReviews);
  reviewsRouter.route("/Testimonials").get(getTestimonials);

  return reviewsRouter;
}
module.exports = router;
