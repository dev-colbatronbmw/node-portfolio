const express = require("express");
const { check } = require("express-validator");

const shopController = require("../controllers/shopController");

const shopRouter = express.Router();

function router() {
  const {
    getShop,
    getSpiceRubs,
    getCookbooks,
    getBakingPlanks,
    getBbqPlanks,
    getNutDriver,
    postAddToCart,
  } = shopController();

  shopRouter.route("/").get(getShop);
  shopRouter.route("/SpiceRubs").get(getSpiceRubs);
  shopRouter.route("/Cookbooks").get(getCookbooks);
  shopRouter.route("/BakingPlanks").get(getBakingPlanks);
  shopRouter.route("/Planks").get(getBakingPlanks);
  shopRouter.route("/BBQPlanks").get(getBbqPlanks);
  shopRouter.route("/NutDriver").get(getNutDriver);
  shopRouter
    .post("/add/:productId", [
      check("quantity")
        .isInt({ gt: 0, lt: 100 })
        .withMessage("You Must enter a number"),
      postAddToCart,
    ])
    .post(postAddToCart);

  return shopRouter;
}
module.exports = router;
