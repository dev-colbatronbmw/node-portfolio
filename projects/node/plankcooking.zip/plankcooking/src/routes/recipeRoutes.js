const express = require("express");
const { check } = require("express-validator");

const recipeController = require("../controllers/recipeController");

const reviewsRouter = express.Router();

function router() {
  const { getRecipes } = recipeController();

  reviewsRouter.route("/").get(getRecipes);

  return reviewsRouter;
}
module.exports = router;
