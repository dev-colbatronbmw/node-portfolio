const express = require("express");
const { check } = require("express-validator");

const cartController = require("../controllers/cartController");

const cartRouter = express.Router();

function router() {
  const {
    getCart,
    getSetCart,
    getClearCart,
    postAddToCart,
    getCheckout,
    putCheckout,
    putSameCheckout,
    getCartReview,
    postComplete,
    getReceipt,
    postDelete,
    getSameCheckout,
  } = cartController();

  cartRouter.route("/").get(getCart);
  cartRouter
    .post("/add/:productId", [
      check("quantity").isNumeric().withMessage("You Must enter a number"),
      postAddToCart,
    ])
    .post(postAddToCart);
  cartRouter.route("/set-cart").get(getSetCart);
  cartRouter.route("/clear-cart").get(getClearCart);

  cartRouter.route("/checkout").get(getCheckout);
  cartRouter.route("/checkout-same").get(getSameCheckout);
  cartRouter
    .post("/checkout-cart", [
      check("firstName")
        .isLength({ min: 3 })
        .withMessage("A first name must be at least 3 characters."),
      check("lastName")
        .isLength({ min: 3 })
        .withMessage("A last name must be at least 3 characters."),
      check("address1")
        .isLength({ min: 3 })
        .withMessage("Address must be valid"),
      check("state").isLength({ min: 2 }).withMessage("State Must be valid"),
      check("city").isLength({ min: 3 }).withMessage("City Must be valid"),
      check("zip")
        .isNumeric()
        .withMessage("You Must enter a valid zip code number"),
      check("shipFirstName")
        .isLength({ min: 3 })
        .withMessage("A first name in shipping must be at least 3 characters."),
      check("shipLastName")
        .isLength({ min: 3 })
        .withMessage("A last name in shipping must be at least 3 characters."),
      check("shipAddress1")
        .isLength({ min: 3 })
        .withMessage("Shipping Address must be valid"),
      check("shipState")
        .isLength({ min: 2 })
        .withMessage("Shipping State Must be valid"),
      check("shipCity").isLength({ min: 3 }).withMessage("City Must be valid"),
      check("shipZip")
        .isNumeric()
        .withMessage("You Must enter a valid Shipping zip code number"),
      putCheckout,
    ])
    .post(putCheckout);

  cartRouter
    .post("/checkout-cart-same", [
      check("firstName")
        .isLength({ min: 3 })
        .withMessage("A first name must be at least 3 characters."),
      check("lastName")
        .isLength({ min: 3 })
        .withMessage("A last name must be at least 3 characters."),
      check("address1")
        .isLength({ min: 3 })
        .withMessage("Address must be valid"),
      check("state").isLength({ min: 2 }).withMessage("State Must be valid"),
      check("city").isLength({ min: 3 }).withMessage("City Must be valid"),
      check("zip")
        .isNumeric()
        .withMessage("You Must enter a valid zip code number"),
      putSameCheckout,
    ])
    .post(putSameCheckout);

  cartRouter.route("/Review").get(getCartReview);
  cartRouter
    .route("/complete", [
      check("cardNumber")
        .matches(/\b\d{16}\b/)
        .withMessage("You Must enter a valid 16 digit card number"),
      postComplete,
    ])
    .post(postComplete);
  cartRouter.route("/Receipt").get(getReceipt);
  cartRouter.route("/remove/:productId").post(postDelete);
  return cartRouter;
}
module.exports = router;
