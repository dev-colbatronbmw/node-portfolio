/* eslint-disable operator-linebreak */
const debug = require("debug")("app:cartController");
const sql = require("mssql");
const csurf = require("csurf");
const { validationResult } = require("express-validator");

function cartController() {
  let errors = [];
  async function getCartData(cartID) {
    const request = new sql.Request();
    const cart = [];
    const result = await request
      .input("cartID", sql.Int, cartID)
      .query("SELECT * FROM dbo.Cart WHERE CartID=@cartID");
    result.recordset.forEach((_cartItem) => {
      const cartItem = {
        productId: _cartItem.ProductId,
        quantity: _cartItem.Quantity,
      };
      cart.push(cartItem);
    });
    return cart;
  }
  async function getProducts() {
    const request = new sql.Request();
    const products = [];
    const result = await request.query("SELECT * FROM dbo.Products");
    result.recordset.forEach((_product) => {
      const product = {
        productId: _product.ProductId,
        name: _product.Name,
        description: _product.Description,
        category: _product.Category,
        price: _product.Price,
        src: _product.ImgUrl,
        weight: _product.Weight,
        size: _product.Size,
        inStock: _product.InStock,
      };
      products.push(product);
    });
    return products;
  }
  async function getOrderData() {
    const request = new sql.Request();
    const orders = [];
    const result = await request.query("SELECT * FROM dbo.Orders");
    result.recordset.forEach((_order) => {
      const order = {
        orderId: _order.OrderID,
        cartId: _order.CartId,
        completedOrder: _order.CompletedOrder,
        firstName: _order.FirstName,
        lastName: _order.LastName,
        address1: _order.AddressOne,
        address2: _order.AddressTwo,
        city: _order.City,
        state: _order.State,
        zip: _order.Zip,
        phone: _order.Phone,
        email: _order.Email,
        shipFirstName: _order.ShipFirstName,
        shipLastName: _order.ShipLastName,
        shipAddress1: _order.ShipAddressOne,
        shipAddress2: _order.ShipAddressTwo,
        shipCity: _order.ShipCity,
        shipState: _order.ShipState,
        shipZip: _order.ShipZip,
        shipPhone: _order.ShipPhone,
        shipEmail: _order.ShipEmail,
        shippingType: _order.ShippingType,
        shippingPrice: _order.ShippingPrice,
        orderComments: _order.OrderComments,
        cardType: _order.CardType,
        cardNumber: _order.CardNumber,
        confirmationCode: _order.ConfirmationCode,
      };
      orders.push(order);
    });
    return orders;
  }

  function getSetCart(req, res) {
    debug("set Cart: ", "Working");
    const session = {
      id: 1,
    };
    res.cookie("session", session, { maxAge: 1800000 });
    res.redirect("/shop/SpiceRubs");
  }

  function getCart(req, res) {
    let { session } = req.cookies;
    debug("all cookies: ", req.cookies);
    debug("session data for get: ", session);
    debug("Get Cart: ", "Working");
    // eslint-disable-next-line eqeqeq
    if (session == undefined) {
      session = {
        id: 0,
      };
    }
    (async () => {
      const cartData = await getCartData(session.id);
      const products = await getProducts();
      debug("cookie data: ", "Working");
      debug("cart in get: ", cartData);
      const cart = [];
      let productId;
      let name;
      let price;
      let quantity;
      let total;
      let subtotal = 0.0;

      cartData.forEach((cartItem) => {
        debug("cart item", cartItem.productId);
        debug("cart item quantity", cartItem.quantity);
        products.forEach((product) => {
          if (cartItem.productId === product.productId) {
            productId = cartItem.productId;
            name = product.name;
            price = product.price;
            quantity = cartItem.quantity;
            total = price * quantity;

            cart.push({
              productId,
              name,
              price,
              quantity,
              total,
            });
          }
        });
      });

      cart.forEach((cartItem) => {
        debug("cartItem Total: ", parseFloat(cartItem.total));
        subtotal += parseFloat(cartItem.total);
      });
      debug("subtotal: ", subtotal);
      res.render("cart", {
        cart,
        products,
        session,
        subtotal,
        csrfToken: req.csrfToken(),
        errors,
      });
    })();
  }

  function getClearCart(req, res) {
    debug("Cookies: ", "cleared");
    res.clearCookie("session");
    res.redirect("/shop/SpiceRubs");
  }

  function postAddToCart(req, res) {
    debug("all cookies: ", req.cookies);
    const validatorErrors = validationResult(req);
    errors = validatorErrors.array();
    debug("all cookies: ", req.cookies);
    let { session } = req.cookies;
    debug("cart item id: ", req.params.productId);
    debug("cart item quantity from form: ", req.body.quantity);
    (async () => {
      let cart = [];
      const orders = await getOrderData();
      debug("orders number in post: ", orders.length);
      if (!session) {
        debug("session null: ", session);
        session = {
          id: orders.length + 1,
        };
        res.cookie("session", session, { maxAge: 180000000 });
      }
      if (session) {
        debug("session not null: ", session.id);
        cart = await getCartData(session.id);
        debug("cart length in post: ", cart.length);
        debug("cart in get: ", cart);
        if (cart.length === 0) {
          debug("session null: ", session);
          session = {
            id: orders.length + 1,
          };
          res.cookie("session", session, { maxAge: 180000000 });
          let request = new sql.Request();
          await request
            .input("orderId", sql.Int, session.id)
            .input("cartId", sql.Int, session.id)
            .query(
              "INSERT INTO dbo.Orders(OrderID, CartId) VALUES (@orderId, @cartId)"
            );
          debug("Started new order", "!");
          request = new sql.Request();
          await request
            .input("cartId", sql.Int, session.id)
            .input("productId", sql.Int, req.params.productId)
            .input("quantity", sql.Int, req.body.quantity)
            .query(
              "INSERT INTO dbo.Cart(CartID, ProductId, Quantity) VALUES (@cartId, @productId, @quantity)"
            );
          debug("added to cart", " in 0 length section ");
        } else {
          let q;
          let update = false;
          cart.forEach((cartItem) => {
            const cartpid = cartItem.productId;
            const paramsId = req.params.productId;
            debug("cartpid", cartpid);
            debug("params id", paramsId);
            // eslint-disable-next-line eqeqeq
            if (cartpid == paramsId) {
              update = true;
              q = cartItem.quantity;
              debug("should update", update);
            }
          });
          debug("should update", update);
          if (update) {
            // eslint-disable-next-line radix
            const quantity = parseInt(q) + parseInt(req.body.quantity);
            const request = new sql.Request();
            await request
              .input("quantity", sql.Int, quantity)
              .input("productId", sql.Int, req.params.productId)
              .query(
                "UPDATE dbo.Cart SET Quantity=@quantity WHERE ProductId=@productId"
              );
            debug("updated cart", "no new order");
          } else {
            const request = new sql.Request();
            await request
              .input("cartId", sql.Int, session.id)
              .input("productId", sql.Int, req.params.productId)
              .input("quantity", sql.Int, req.body.quantity)
              .query(
                "INSERT INTO dbo.Cart(CartID, ProductId, Quantity) VALUES (@cartId, @productId, @quantity)"
              );
            debug("added to cart", "but no new order!");
            debug("add to cart here:", "?");
          }
        }
      }

      debug("body product id that is being added", req.params.productId);

      if (parseInt(req.params.productId) < 7) {
        res.redirect("/shop/SpiceRubs");
      } else if (
        // eslint-disable-next-line radix
        parseInt(req.params.productId) > 6 &&
        parseInt(req.params.productId) < 11
      ) {
        res.redirect("/shop/Cookbooks");
      } else if (
        parseInt(req.params.productId) > 10 &&
        parseInt(req.params.productId) < 15
      ) {
        res.redirect("/shop/BakingPlanks");
      } else if (
        parseInt(req.params.productId) > 14 &&
        parseInt(req.params.productId) < 16
      ) {
        res.redirect("/shop/BBQPlanks");
        // eslint-disable-next-line radix
      } else if (parseInt(req.params.productId) === 16) {
        res.redirect("/shop/NutDriver");
      }
    })();
  }

  function getCheckout(req, res) {
    debug("getting to checkout:", "?");
    const { session } = req.cookies;
    (async () => {
      const request = new sql.Request();
      const result = await request
        .input("orderId", sql.Int, session.id)
        .query("SELECT * FROM dbo.Orders WHERE OrderID=@orderId");
      const order = result.recordset[0];
      // debug("order: ", order);
      const cartData = await getCartData(session.id);
      const products = await getProducts();
      const cart = [];
      let name;
      let price;
      let quantity;
      let total;
      let subtotal = 0.0;

      cartData.forEach((cartItem) => {
        debug("cart item", cartItem.productId);
        debug("cart item quantity", cartItem.quantity);
        products.forEach((product) => {
          if (cartItem.productId === product.productId) {
            name = product.name;
            price = product.price;
            quantity = cartItem.quantity;
            total = price * quantity;

            cart.push({
              name,
              price,
              quantity,
              total,
            });
          }
        });
      });

      debug("cart: ", cart);
      cart.forEach((cartItem) => {
        debug("cartItem Total: ", parseFloat(cartItem.total));
        subtotal += parseFloat(cartItem.total);
      });

      // debug("cart: ", cart);

      res.render("cart/checkout", {
        order: {
          orderId: order.OrderID,
          cartId: order.CartId,
          completedOrder: order.CompletedOrder,
          firstName: order.FirstName,
          lastName: order.LastName,
          address1: order.AddressOne,
          address2: order.AddressTwo,
          city: order.City,
          state: order.State,
          zip: order.Zip,
          phone: order.Phone,
          email: order.Email,
          shipFirstName: order.ShipFirstName,
          shipLastName: order.ShipLastName,
          shipAddress1: order.ShipAddressOne,
          shipAddress2: order.ShipAddressTwo,
          shipCity: order.ShipCity,
          shipState: order.ShipState,
          shipZip: order.ShipZip,
          shipPhone: order.ShipPhone,
          shipEmail: order.ShipEmail,
          shippingType: order.ShippingType,
          shippingPrice: order.ShippingPrice,
          orderComments: order.OrderComments,
          cardType: order.CardType,
          cardNumber: order.CardNumber,
          confirmationCode: order.ConfirmationCode,
        },
        cart,
        subtotal,
        csrfToken: req.csrfToken(),
        errors,
      });
    })();
  }

  function getSameCheckout(req, res) {
    debug("getting to checkout:", "?");
    const { session } = req.cookies;
    (async () => {
      const request = new sql.Request();
      const result = await request
        .input("orderId", sql.Int, session.id)
        .query("SELECT * FROM dbo.Orders WHERE OrderID=@orderId");
      const order = result.recordset[0];
      // debug("order: ", order);
      const cartData = await getCartData(session.id);
      const products = await getProducts();
      const cart = [];
      let name;
      let price;
      let quantity;
      let total;
      let subtotal = 0.0;

      cartData.forEach((cartItem) => {
        debug("cart item", cartItem.productId);
        debug("cart item quantity", cartItem.quantity);
        products.forEach((product) => {
          if (cartItem.productId === product.productId) {
            name = product.name;
            price = product.price;
            quantity = cartItem.quantity;
            total = price * quantity;

            cart.push({
              name,
              price,
              quantity,
              total,
            });
          }
        });
      });

      debug("cart: ", cart);
      cart.forEach((cartItem) => {
        debug("cartItem Total: ", parseFloat(cartItem.total));
        subtotal += parseFloat(cartItem.total);
      });

      // debug("cart: ", cart);

      res.render("cart/checkout-same", {
        order: {
          orderId: order.OrderID,
          cartId: order.CartId,
          completedOrder: order.CompletedOrder,
          firstName: order.FirstName,
          lastName: order.LastName,
          address1: order.AddressOne,
          address2: order.AddressTwo,
          city: order.City,
          state: order.State,
          zip: order.Zip,
          phone: order.Phone,
          email: order.Email,
          shipFirstName: order.ShipFirstName,
          shipLastName: order.ShipLastName,
          shipAddress1: order.ShipAddressOne,
          shipAddress2: order.ShipAddressTwo,
          shipCity: order.ShipCity,
          shipState: order.ShipState,
          shipZip: order.ShipZip,
          shipPhone: order.ShipPhone,
          shipEmail: order.ShipEmail,
          shippingType: order.ShippingType,
          shippingPrice: order.ShippingPrice,
          orderComments: order.OrderComments,
          cardType: order.CardType,
          cardNumber: order.CardNumber,
          confirmationCode: order.ConfirmationCode,
        },
        cart,
        subtotal,
        csrfToken: req.csrfToken(),
        errors,
      });
    })();
  }

  function putCheckout(req, res) {
    debug("putting the stuff", "put checkout");
    const { session } = req.cookies;
    (async () => {
      const request = new sql.Request();
      debug("putting the stuff");
      debug("same as billing", req.body.same);

      await request
        .input("firstName", sql.NVarChar, req.body.firstName)
        .input("lastName", sql.NVarChar, req.body.lastName)
        .input("address1", sql.NVarChar, req.body.address1)
        .input("address2", sql.NVarChar, req.body.address2)
        .input("city", sql.NVarChar, req.body.city)
        .input("state", sql.NVarChar, req.body.state)
        .input("zip", sql.Int, req.body.zip)
        .input("phone", sql.NVarChar, req.body.phone)
        .input("email", sql.NVarChar, req.body.email)
        .input("shipFirstName", sql.NVarChar, req.body.shipFirstName)
        .input("shipLastName", sql.NVarChar, req.body.shipLastName)
        .input("shipAddress1", sql.NVarChar, req.body.shipAddress1)
        .input("shipAddress2", sql.NVarChar, req.body.shipAddress2)
        .input("shipCity", sql.NVarChar, req.body.shipCity)
        .input("shipState", sql.NVarChar, req.body.shipState)
        .input("shipZip", sql.Int, req.body.shipZip)
        .input("shipPhone", sql.NVarChar, req.body.shipPhone)
        .input("shipEmail", sql.NVarChar, req.body.shipEmail)
        .input("orderComments", sql.NVarChar, req.body.orderComments)

        .input("orderId", sql.Int, session.id)
        .query(
          "UPDATE dbo.Orders SET FirstName=@firstName, LastName=@lastName, AddressOne=@address1, AddressTwo=@address2, City=@city, State=@state, Zip=@zip, Phone=@phone, Email=@email, ShipFirstName=@shipFirstName, ShipLastName=@shipLastName, ShipAddressOne=@shipAddress1, ShipAddressTwo=@shipAddress2, ShipCity=@shipCity, ShipState=@shipState, ShipZip=@shipZip, ShipPhone=@shipPhone, ShipEmail=@shipEmail, OrderComments=@orderComments WHERE OrderID=@orderId"
        );

      const validatorErrors = validationResult(req);
      errors = validatorErrors.array();
      if (errors.length > 0) {
        res.redirect("checkout");
      } else {
        res.redirect("Review");
      }
    })();
  }

  function putSameCheckout(req, res) {
    debug("putting the stuff", "put checkout");
    const { session } = req.cookies;
    (async () => {
      const request = new sql.Request();
      debug("putting the stuff");
      debug("same as billing", req.body.same);

      await request
        .input("firstName", sql.NVarChar, req.body.firstName)
        .input("lastName", sql.NVarChar, req.body.lastName)
        .input("address1", sql.NVarChar, req.body.address1)
        .input("address2", sql.NVarChar, req.body.address2)
        .input("city", sql.NVarChar, req.body.city)
        .input("state", sql.NVarChar, req.body.state)
        .input("zip", sql.Int, req.body.zip)
        .input("phone", sql.NVarChar, req.body.phone)
        .input("email", sql.NVarChar, req.body.email)
        .input("shipFirstName", sql.NVarChar, req.body.firstName)
        .input("shipLastName", sql.NVarChar, req.body.lastName)
        .input("shipAddress1", sql.NVarChar, req.body.address1)
        .input("shipAddress2", sql.NVarChar, req.body.address2)
        .input("shipCity", sql.NVarChar, req.body.city)
        .input("shipState", sql.NVarChar, req.body.state)
        .input("shipZip", sql.Int, req.body.zip)
        .input("shipPhone", sql.NVarChar, req.body.phone)
        .input("shipEmail", sql.NVarChar, req.body.email)
        .input("orderComments", sql.NVarChar, req.body.orderComments)

        .input("orderId", sql.Int, session.id)
        .query(
          "UPDATE dbo.Orders SET FirstName=@firstName, LastName=@lastName, AddressOne=@address1, AddressTwo=@address2, City=@city, State=@state, Zip=@zip, Phone=@phone, Email=@email, ShipFirstName=@shipFirstName, ShipLastName=@shipLastName, ShipAddressOne=@shipAddress1, ShipAddressTwo=@shipAddress2, ShipCity=@shipCity, ShipState=@shipState, ShipZip=@shipZip, ShipPhone=@shipPhone, ShipEmail=@shipEmail, OrderComments=@orderComments WHERE OrderID=@orderId"
        );

      const validatorErrors = validationResult(req);
      errors = validatorErrors.array();
      if (errors.length > 0) {
        res.redirect("checkout");
      } else {
        res.redirect("Review");
      }
    })();
  }

  function getCartReview(req, res) {
    // const orderId = req.params.orderId
    (async () => {
      const { session } = req.cookies;
      const request = new sql.Request();
      const result = await request
        .input("orderId", sql.Int, session.id)
        .query("SELECT * FROM dbo.Orders WHERE OrderID=@orderId");
      const order = result.recordset[0];
      debug("order: ", order);
      const cartData = await getCartData(session.id);
      const products = await getProducts();
      const cart = [];
      let name;
      let price;
      let quantity;
      let total;
      let subtotal = 0.0;

      cartData.forEach((cartItem) => {
        debug("cart item", cartItem.productId);
        debug("cart item quantity", cartItem.quantity);
        products.forEach((product) => {
          if (cartItem.productId === product.productId) {
            name = product.name;
            price = product.price;
            quantity = cartItem.quantity;
            total = price * quantity;

            cart.push({
              name,
              price,
              quantity,
              total,
              errors,
            });
          }
        });
      });

      debug("cart: ", cart);
      cart.forEach((cartItem) => {
        debug("cartItem Total: ", parseFloat(cartItem.total));
        subtotal += parseFloat(cartItem.total);
      });
      const finalTotal = subtotal + 6.99;
      debug("cart: ", cart);
      res.render("cart/review", {
        order: {
          orderId: order.OrderID,
          cartId: order.CartId,
          completedOrder: order.CompletedOrder,
          firstName: order.FirstName,
          lastName: order.LastName,
          address1: order.AddressOne,
          address2: order.AddressTwo,
          city: order.City,
          state: order.State,
          zip: order.Zip,
          phone: order.Phone,
          email: order.Email,
          shipFirstName: order.ShipFirstName,
          shipLastName: order.ShipLastName,
          shipAddress1: order.ShipAddressOne,
          shipAddress2: order.ShipAddressTwo,
          shipCity: order.ShipCity,
          shipState: order.ShipState,
          shipZip: order.ShipZip,
          shipPhone: order.ShipPhone,
          shipEmail: order.ShipEmail,
          shippingType: order.ShippingType,
          shippingPrice: order.ShippingPrice,
          orderComments: order.OrderComments,
          cardType: order.CardType,
          cardNumber: order.CardNumber,
          confirmationCode: order.ConfirmationCode,
        },
        cart,
        subtotal,
        finalTotal,
        csrfToken: req.csrfToken(),
        errors,
      });
    })();
  }
  function postComplete(req, res) {
    debug("putting the stuff", "put checkout");
    const { session } = req.cookies;
    (async () => {
      // todo create confirmation code and shipping price
      const confirmationCode = 123456789;
      const shippingPrice = 6.99;
      let request = new sql.Request();
      debug("putting the stuff");
      await request
        .input("shippingType", sql.NVarChar, req.body.shippingType)
        .input("shippingPrice", sql.Float, shippingPrice)
        .input("cardType", sql.NVarChar, req.body.cardType)
        .input("cardNumber", sql.NVarChar, req.body.cardNumber)
        .input("confirmationCode", sql.NVarChar, confirmationCode)
        .input("orderId", sql.Int, session.id)
        .input("finalTotal", sql.Float, req.body.finalTotal)
        .input("completedOrder", sql.Int, 1)
        .query(
          "UPDATE dbo.Orders SET ShippingType=@shippingType, ShippingPrice=@shippingPrice, CardType=@cardType, CardNumber=@cardNumber, ConfirmationCode=@confirmationCode, Total=@finalTotal, CompletedOrder=@completedOrder WHERE OrderID=@orderId"
        );

      request = new sql.Request();
      await request
        .input("orderId", sql.Int, session.id)
        .input("cartId", sql.Int, session.id)
        .input("finalTotal", sql.Float, req.body.finalTotal)
        .input("confirmationCode", sql.Int, confirmationCode)
        .input("shipped", sql.Int, 0)
        .query(
          "INSERT INTO dbo.Purchases(OrderID,CartID, Total, ConfirmationCode, Shipped) VALUES (@orderId, @cartId, @finalTotal, @confirmationCode, @shipped)"
        );
      res.redirect("/cart/receipt");
    })();
  }

  function getReceipt(req, res) {
    (async () => {
      const { session } = req.cookies;
      const cartData = await getCartData(session.id);
      const products = await getProducts();
      const request = new sql.Request();
      const result = await request
        .input("orderId", sql.Int, session.id)
        .query("SELECT * FROM dbo.Orders WHERE OrderID=@orderId");
      const order = result.recordset[0];
      debug("order: ", order);
      const cart = [];
      let name;
      let price;
      let quantity;
      let total;
      let subtotal = 0.0;

      cartData.forEach((cartItem) => {
        debug("cart item", cartItem.productId);
        debug("cart item quantity", cartItem.quantity);
        products.forEach((product) => {
          if (cartItem.productId === product.productId) {
            name = product.name;
            price = product.price;
            quantity = cartItem.quantity;
            total = price * quantity;

            cart.push({
              name,
              price,
              quantity,
              total,
              csrfToken: req.csrfToken(),
              errors,
            });
          }
        });
      });

      debug("cart: ", cart);
      cart.forEach((cartItem) => {
        debug("cartItem Total: ", parseFloat(cartItem.total));
        subtotal += parseFloat(cartItem.total);
      });
      const finalTotal = subtotal + 6.99;
      debug("recipt cart: ", cart);
      debug("recipt order: ", order);
      debug("Cookies: ", "cleared");
      res.clearCookie("session");
      res.render("cart/receipt", {
        order: {
          orderId: order.OrderID,
          cartId: order.CartId,
          completedOrder: order.CompletedOrder,
          firstName: order.FirstName,
          lastName: order.LastName,
          address1: order.AddressOne,
          address2: order.AddressTwo,
          city: order.City,
          state: order.State,
          zip: order.Zip,
          phone: order.Phone,
          email: order.Email,
          shipFirstName: order.ShipFirstName,
          shipLastName: order.ShipLastName,
          shipAddress1: order.ShipAddressOne,
          shipAddress2: order.ShipAddressTwo,
          shipCity: order.ShipCity,
          shipState: order.ShipState,
          shipZip: order.ShipZip,
          shipPhone: order.ShipPhone,
          shipEmail: order.ShipEmail,
          shippingType: order.ShippingType,
          shippingPrice: order.ShippingPrice,
          orderComments: order.OrderComments,
          cardType: order.CardType,
          cardNumber: order.CardNumber,
          confirmationCode: order.ConfirmationCode,
        },
        cart,
        products,
        subtotal,
        finalTotal,
        csrfToken: req.csrfToken(),
        errors,
      });
    })();
  }

  function postDelete(req, res) {
    const { session } = req.cookies;
    const { productId } = req.params;
    (async () => {
      const request = new sql.Request();
      await request
        .input("productId", sql.Int, productId)
        .input("cartId", sql.Int, session.id)
        .query(
          "DELETE FROM dbo.Cart WHERE ProductId=@productId AND CartID=@cartId"
        );

      res.redirect("/cart");
    })();
  }

  return {
    getCart,
    getSetCart,
    getClearCart,
    postAddToCart,
    getCheckout,
    putCheckout,
    putSameCheckout,
    getCartReview,
    postComplete,
    getReceipt,
    postDelete,
    getSameCheckout,
  };
}
module.exports = cartController;
