const debug = require("debug")("app:reviewsController");

function reviewsController() {
  debug("reviews controller: ", "working");

  function getReviews(req, res) {
    debug("Get reviews: ", "Working");
    // res.send("about test");
    res.render("reviews", {});
  }
  function getTestimonials(req, res) {
    debug("Get reviews: ", "Working");
    // res.send("about test");
    res.render("reviews/testimonials", {});
  }

  return {
    getReviews,
    getTestimonials,
  };
}
module.exports = reviewsController;
