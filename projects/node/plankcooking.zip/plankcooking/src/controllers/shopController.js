const debug = require("debug")("app:shopController");
const sql = require("mssql");
const { validationResult } = require("express-validator");

function shopController() {
  let errors = [];
  let attempted = 0;
  let succeded = 0;
  async function getCartData(cartID) {
    const request = new sql.Request();
    const cart = [];
    const result = await request
      .input("cartID", sql.Int, cartID)
      .query("SELECT * FROM dbo.Cart WHERE CartID=@cartID");
    result.recordset.forEach((_cartItem) => {
      const cartItem = {
        productId: _cartItem.ProductId,
        quantity: _cartItem.Quantity,
      };
      cart.push(cartItem);
    });
    return cart;
  }
  async function getProducts() {
    const request = new sql.Request();
    const products = [];
    const result = await request.query("SELECT * FROM dbo.Products");
    result.recordset.forEach((_product) => {
      const product = {
        productId: _product.ProductId,
        name: _product.Name,
        description: _product.Description,
        category: _product.Category,
        price: _product.Price,
        src: _product.ImgUrl,
        weight: _product.Weight,
        size: _product.Size,
        inStock: _product.InStock,
      };
      products.push(product);
    });
    return products;
  }
  async function getOrderData() {
    const request = new sql.Request();
    const orders = [];
    const result = await request.query("SELECT * FROM dbo.Orders");
    result.recordset.forEach((_order) => {
      const order = {
        orderId: _order.OrderID,
        cartId: _order.CartId,
        completedOrder: _order.CompletedOrder,
        firstName: _order.FirstName,
        lastName: _order.LastName,
        address1: _order.AddressOne,
        address2: _order.AddressTwo,
        city: _order.City,
        state: _order.State,
        zip: _order.Zip,
        phone: _order.Phone,
        email: _order.Email,
        shipFirstName: _order.ShipFirstName,
        shipLastName: _order.ShipLastName,
        shipAddress1: _order.ShipAddressOne,
        shipAddress2: _order.ShipAddressTwo,
        shipCity: _order.ShipCity,
        shipState: _order.ShipState,
        shipZip: _order.ShipZip,
        shipPhone: _order.ShipPhone,
        shipEmail: _order.ShipEmail,
        shippingType: _order.ShippingType,
        shippingPrice: _order.ShippingPrice,
        orderComments: _order.OrderComments,
        cardType: _order.CardType,
        cardNumber: _order.CardNumber,
        confirmationCode: _order.ConfirmationCode,
      };
      orders.push(order);
    });
    return orders;
  }

  debug("shop controller: ", "working");

  function postAddToCart(req, res) {
    debug("all cookies: ", req.cookies);
    const validatorErrors = validationResult(req);
    errors = validatorErrors.array();
    debug("all cookies: ", req.cookies);
    let { session } = req.cookies;
    if (errors.length > 0) {
      attempted = {
        // eslint-disable-next-line radix
        attempted: parseInt(req.params.productId),
      };
    } else {
      succeded = {
        // eslint-disable-next-line radix
        succeded: parseInt(req.params.productId),
      };
    }

    debug("cart item id: ", req.params.productId);
    debug("cart item quantity from form: ", req.body.quantity);

    if (errors.length === 0) {
      (async () => {
        let cart = [];
        const orders = await getOrderData();
        debug("orders number in post: ", orders.length);
        if (!session) {
          debug("session null: ", session);
          session = {
            id: orders.length + 1,
          };
          res.cookie("session", session, { maxAge: 180000000 });
        }
        if (session) {
          debug("session not null: ", session.id);
          cart = await getCartData(session.id);
          debug("cart length in post: ", cart.length);
          debug("cart in get: ", cart);
          if (cart.length === 0) {
            debug("session null: ", session);
            session = {
              id: orders.length + 1,
            };
            res.cookie("session", session, { maxAge: 180000000 });
            let request = new sql.Request();
            await request
              .input("orderId", sql.Int, session.id)
              .input("cartId", sql.Int, session.id)
              .query(
                "INSERT INTO dbo.Orders(OrderID, CartId) VALUES (@orderId, @cartId)"
              );
            debug("Started new order", "!");
            request = new sql.Request();
            await request
              .input("cartId", sql.Int, session.id)
              .input("productId", sql.Int, req.params.productId)
              .input("quantity", sql.Int, req.body.quantity)
              .query(
                "INSERT INTO dbo.Cart(CartID, ProductId, Quantity) VALUES (@cartId, @productId, @quantity)"
              );
            debug("added to cart", " in 0 length section ");
          } else {
            let q;
            let update = false;
            cart.forEach((cartItem) => {
              const cartpid = cartItem.productId;
              const paramsId = req.params.productId;
              debug("cartpid", cartpid);
              debug("params id", paramsId);
              // eslint-disable-next-line eqeqeq
              if (cartpid == paramsId) {
                update = true;
                q = cartItem.quantity;
                debug("should update", update);
              }
            });
            debug("should update", update);
            if (update) {
              // eslint-disable-next-line radix
              const quantity = parseInt(q) + parseInt(req.body.quantity);
              const request = new sql.Request();
              await request
                .input("quantity", sql.Int, quantity)
                .input("productId", sql.Int, req.params.productId)
                .query(
                  "UPDATE dbo.Cart SET Quantity=@quantity WHERE ProductId=@productId"
                );
              debug("updated cart", "no new order");
            } else {
              const request = new sql.Request();
              await request
                .input("cartId", sql.Int, session.id)
                .input("productId", sql.Int, req.params.productId)
                .input("quantity", sql.Int, req.body.quantity)
                .query(
                  "INSERT INTO dbo.Cart(CartID, ProductId, Quantity) VALUES (@cartId, @productId, @quantity)"
                );
              debug("added to cart", "but no new order!");
              debug("add to cart here:", "?");
            }
          }
        }

        debug("body product id that is being added", req.params.productId);

        if (parseInt(req.params.productId) < 7) {
          res.redirect("/shop/SpiceRubs");
        } else if (
          parseInt(req.params.productId) > 6 &&
          parseInt(req.params.productId) < 11
        ) {
          res.redirect("/shop/Cookbooks");
        } else if (
          parseInt(req.params.productId) > 10 &&
          parseInt(req.params.productId) < 25
        ) {
          res.redirect("/shop/BakingPlanks");
        } else if (
          parseInt(req.params.productId) > 24 &&
          parseInt(req.params.productId) < 26
        ) {
          res.redirect("/shop/BBQPlanks");
        } else if (parseInt(req.params.productId) === 26) {
          res.redirect("/shop/NutDriver");
        }
      })();
    } else if (errors.length > 0) {
      if (parseInt(req.params.productId) < 7) {
        res.redirect("/shop/SpiceRubs");
      } else if (
        parseInt(req.params.productId) > 6 &&
        parseInt(req.params.productId) < 11
      ) {
        res.redirect("/shop/Cookbooks");
      } else if (
        parseInt(req.params.productId) > 10 &&
        parseInt(req.params.productId) < 25
      ) {
        res.redirect("/shop/BakingPlanks");
      } else if (
        parseInt(req.params.productId) > 24 &&
        parseInt(req.params.productId) < 26
      ) {
        res.redirect("/shop/BBQPlanks");
      } else if (parseInt(req.params.productId) === 26) {
        res.redirect("/shop/NutDriver");
      }
    }
  }

  function getShop(req, res) {
    debug("Get shop: ", "Working");

    // res.send("about test");
    res.render("shop", { csrfToken: req.csrfToken(), attempted, succeded });
  }

  function getSpiceRubs(req, res) {
    const { session } = req.cookies;
    if (session) {
      debug("shop session cookie id: ", session.id);
    } else {
      debug("shop session cookie id: ", "empty");
    }

    debug("Get shop: ", "Working");
    (async () => {
      const products = await getProducts();
      res.render("shop/spice-rubs", {
        products,
        csrfToken: req.csrfToken(),
        errors,
        attempted,
        succeded,
      });
      succeded = 0;
      // res.send("about test");
    })();
  }

  function getCookbooks(req, res) {
    // const validatorErrors = validationResult(req);
    // errors = validatorErrors.array();
    const { session } = req.cookies;
    if (session) {
      debug("shop session cookie id: ", session.id);
    } else {
      debug("shop session cookie id: ", "empty");
    }
    debug("Get shop: ", "Working");
    (async () => {
      const products = await getProducts();
      res.render("shop/cookbooks", {
        products,
        csrfToken: req.csrfToken(),
        errors,
        attempted,
        succeded,
      });
      succeded = 0;
      // res.send("about test");
    })();
  }
  function getBakingPlanks(req, res) {
    // const validatorErrors = validationResult(req);
    // errors = validatorErrors.array();
    const { session } = req.cookies;
    if (session) {
      debug("shop session cookie id: ", session.id);
    } else {
      debug("shop session cookie id: ", "empty");
    }

    debug("Get shop: ", "Working");
    (async () => {
      const products = await getProducts();
      res.render("shop/baking-planks", {
        products,
        csrfToken: req.csrfToken(),
        errors,
        attempted,
        succeded,
      });
      succeded = 0;
      // res.send("about test");
    })();
  }
  function getBbqPlanks(req, res) {
    // const validatorErrors = validationResult(req);
    // errors = validatorErrors.array();
    const { session } = req.cookies;
    if (session) {
      debug("shop session cookie id: ", session.id);
    } else {
      debug("shop session cookie id: ", "empty");
    }

    debug("Get shop: ", "Working");
    (async () => {
      const products = await getProducts();
      res.render("shop/bbq-planks", {
        products,
        csrfToken: req.csrfToken(),
        errors,
        attempted,
        succeded,
      });
      succeded = 0;
      // res.send("about test");
    })();
  }
  function getNutDriver(req, res) {
    // const validatorErrors = validationResult(req);
    // errors = validatorErrors.array();
    const { session } = req.cookies;
    if (session) {
      debug("shop session cookie id: ", session.id);
    } else {
      debug("shop session cookie id: ", "empty");
    }

    debug("Get shop: ", "Working");
    (async () => {
      const products = await getProducts();
      res.render("shop/nut-driver", {
        products,
        csrfToken: req.csrfToken(),
        errors,
        attempted,
        succeded,
      });
      succeded = 0;
      // res.send("about test");
    })();
  }

  return {
    getShop,
    getSpiceRubs,
    getCookbooks,
    getBakingPlanks,
    getBbqPlanks,
    getNutDriver,
    postAddToCart,
  };
}
module.exports = shopController;
