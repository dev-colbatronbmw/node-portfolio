const debug = require("debug")("app:recipesController");

function recipeController() {
  debug("recipies controller: ", "working");

  function getRecipes(req, res) {
    debug("Get reviews: ", "Working");
    // res.send("about test");
    res.render("recipes", {});
  }

  return {
    getRecipes,
  };
}
module.exports = recipeController;
