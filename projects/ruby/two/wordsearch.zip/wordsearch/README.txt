Word search instructions
For this assignment we were to read in a test document and use the words to make a pdf that had those words in a word search. 
